class Forma():
    def __init__(self) -> None:
        pass
    def __str__(self) -> str:
        return "Forma"