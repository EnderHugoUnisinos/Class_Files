class Ingresso():
    def __init__(self) -> None:
        self.valor_base = 60.00
    def imprimeValor(self):
        return self.valor_base