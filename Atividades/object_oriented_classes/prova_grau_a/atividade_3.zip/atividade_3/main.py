from data import Data
class System():
    def iniciar_programa(self):
        data_teste_1 = Data("16/10/2004")
        data_teste_2 = Data("16/10/2023")
        data_teste_3 = Data("16/10/2023")
        print(data_teste_1)
        print(data_teste_2)
        print(data_teste_2.compara(data_teste_3))
        print(data_teste_1.compara(data_teste_2))
        print(data_teste_2.compara(data_teste_1))
        
def main():
    system = System()
    system.iniciar_programa()

if __name__ == "__main__":
    main()